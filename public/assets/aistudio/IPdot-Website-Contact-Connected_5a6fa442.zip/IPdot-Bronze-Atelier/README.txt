IPdot — Bronze Atelier website starter

HOW TO PREVIEW
1. Extract the ZIP file.
2. Open the folder.
3. Tap/double-click index.html to preview in a browser.

PAGES
Home, About, Services, Portfolio, Project Detail, Contact, Privacy Policy, Terms & Conditions, 404.

IMPORTANT
- The supplied original IPdot logo artwork is used in the site assets.
- Portfolio cards are explicitly marked as concepts, not client work.
- The contact form prepares a local text file only. It does not send or store messages. Connect a secure backend or a real form service before publishing.
- Replace social placeholder links and review legal copy before launch.
- Google Fonts require an internet connection; fallback fonts are included.

This is a responsive static website package. It can be hosted on any static hosting provider.

CONTACT FORM SETUP
Form endpoint: https://formspree.io/f/moeenged. In Formspree dashboard, confirm notification recipient ipdot07@gmail.com and complete any requested email/domain verification. On successful form submission, the site opens a prefilled WhatsApp message to +91 9343883115; the visitor must press Send in WhatsApp. Test with a sample enquiry before publishing.
